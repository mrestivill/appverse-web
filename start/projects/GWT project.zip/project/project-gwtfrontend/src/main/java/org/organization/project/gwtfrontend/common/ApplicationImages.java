package org.organization.project.gwtfrontend.common;

import org.appverse.web.framework.frontend.gwt.common.FrameworkImages;

import com.google.gwt.resources.client.ImageResource;

public interface ApplicationImages extends FrameworkImages {

}
