package org.organization.project.gwtfrontend.common;

import org.appverse.web.framework.frontend.gwt.common.FrameworkMessages;

public interface ApplicationMessages extends FrameworkMessages {

}
