package org.organization.project.gwtfrontend.main;

import org.organization.project.gwtfrontend.common.ApplicationConstants;

public interface MainConstants extends ApplicationConstants {

	// Add here just module specific constants

}
