package org.organization.project.gwtfrontend.main;

import org.organization.project.gwtfrontend.common.ApplicationMessages;
import com.google.gwt.i18n.client.impl.plurals.DefaultRule_en;

public interface MainMessages extends ApplicationMessages {


}
